package com.example.theno.transforms;

import org.capnproto.PrimitiveList;

import com.example.theno.Definitions;
import com.example.theno.transforms.MessageBase;

public class MsgModelRaw extends MessageBase {

    public Definitions.ModelRaw.Builder modelRaw;
    public PrimitiveList.Float.Builder rawPreds;

    public MsgModelRaw(int size) {
        super();
        initFields(size);
        bytesSerializedForm = computeSerializedMsgBytes();
        initSerializedBuffer();
    }

    private void initFields(int size){
        event = messageBuilder.initRoot(Definitions.Event.factory);
        modelRaw = event.initModelRaw();
        rawPreds = modelRaw.initRawPredictions(size);
    }

    public void fill(float[] outs, long timestamp, int frameId,
                     int frameAge, float frameDropPerc, float modelExecutionTime) {

        modelRaw.setValid(true);
        modelRaw.setModelExecutionTime(modelExecutionTime);
        modelRaw.setFrameId(frameId);
        modelRaw.setFrameIdExtra(frameId);
        modelRaw.setTimestampEof(timestamp);
        modelRaw.setFrameDropPerc(frameDropPerc);
        modelRaw.setFrameAge(frameAge);
        for (int i = 0; i < 6504; i++)
            rawPreds.set(i, outs[i]);
    }
}
