package com.example.theno;

import static android.os.Build.VERSION.SDK_INT;

import static com.example.theno.Path.getModelDir;

import android.Manifest;
import android.app.Application;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import org.nd4j.linalg.api.ndarray.INDArray;
import org.nd4j.linalg.factory.Nd4j;
import org.nd4j.linalg.indexing.NDArrayIndex;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity implements Model.OnModelExecutionListener {
    private TextView sample_text;
    List<String> requiredPermissions = Arrays.asList(android.Manifest.permission.CAMERA,
            android.Manifest.permission.RECORD_AUDIO,
            android.Manifest.permission.READ_PHONE_STATE,
            android.Manifest.permission.WAKE_LOCK,
            Manifest.permission.VIBRATE);
    String modelPath;
    THNEEDModelRunner model;
    ModelExecutorF3 exec;
    private boolean checkPermissions() {
        for (String permission: requiredPermissions){
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        if (SDK_INT >= Build.VERSION_CODES.R)
            return Environment.isExternalStorageManager();
        return true;
    }
    private void requestPermissions() {
        List<String> requestPermissions = new ArrayList<>();
        for (String permission: requiredPermissions){
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED)
                requestPermissions.add(permission);
        }
        if (!requestPermissions.isEmpty())
            ActivityCompat.requestPermissions(this, requestPermissions.toArray(new String[0]), 1);

        // External storage access permissions for android 12 and above.
        if (SDK_INT >= Build.VERSION_CODES.R) {
            if (Environment.isExternalStorageManager())
                return;
            try {
                Toast.makeText(this, "grant external storage access to flowpilot.", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                intent.addCategory("android.intent.category.DEFAULT");
                intent.setData(Uri.parse(String.format("package:%s",getApplicationContext().getPackageName())));
                startActivityForResult(intent, 6969);
            } catch (Exception e) {
                Intent intent = new Intent();
                intent.setAction(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                startActivityForResult(intent, 6969);
            }
        }
    }
    //permissions thread'
    private void ensureBoot(){
        new Thread(new Runnable() {
            public void run() {
                // request permissions and wait till granted.
                requestPermissions();
                int i = 0;
                while (!checkPermissions()){
                    // show toast every 4 seconds
                    if (i%40 == 0) {
                        try {
                            Toast.makeText(getApplicationContext(), "This App needs all required permissions to be granted to work.", Toast.LENGTH_LONG).show();
                        } catch (Exception e) { }
                    }
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                    i++;
                }
                // destroy current activity
                finish();
            }
        }).start();
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Window activity = getWindow();
        activity.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        activity.setSustainedPerformanceMode(true);

        sample_text = findViewById(R.id.sample_text);

        // Show initial status
        updateStatus("Press Button to Download Thneed and Start Execution...");

        // Start the fragment to handle model execution
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, Model.newInstance("param1", "param2"))
                    .commit();
        }
    }
    @Override
    public void onModelExecutionUpdate(String status) {
        runOnUiThread(() -> updateStatus(status));
    }

    @Override
    public void onModelExecutionComplete(String result) {
        runOnUiThread(() -> updateStatus(result));
    }

    private void updateStatus(String status) {
        if (sample_text != null) {
            sample_text.setText(status);
        }
    }
}
