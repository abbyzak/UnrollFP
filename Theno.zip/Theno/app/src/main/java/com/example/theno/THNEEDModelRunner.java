package com.example.theno;

import android.app.Application;
import android.util.Log;

import org.nd4j.linalg.api.ndarray.INDArray;
import java.io.File;
import java.util.Map;


public class THNEEDModelRunner  {

    String modelPath;
    Application context;

    // native function
    public static native void createStdString(String javaString);
    public static native void getArray(int size);
    public static native void initThneed();
    public static native float[] executeModel(float[] input);
    public float[] inputBuffer;

    private final int img_len = 1572864 / 4;
    private final int desire_len = 3200 / 4;

    public THNEEDModelRunner(String modelPath, Application context){
        this.modelPath = "/sdcard/Download/supercombo.thneed";

        this.context = context;

    }
    public void init(Map<String, int[]> shapes, Map<String, int[]> outputShapes) {
        System.loadLibrary("jniconvert");
        createStdString(modelPath);
        getArray(6504);
        initThneed();
        inputBuffer = new float[2 * (1572864 / 4) + (3200 / 4) + 2];
        // new LA model input
        inputBuffer[img_len * 2 + desire_len + 1] = 0.1f; // steering actuator delay
    }

    public void run(Map<String, INDArray> inputMap, Map<String, float[]> outputMap) {
        // new inputs for LA
        inputBuffer[img_len * 2 + desire_len] = 25; // speed in m/s
        // ok regular inputs
        inputMap.get("input_imgs").data().asNioFloat().get(inputBuffer, 0, img_len);
        inputMap.get("big_input_imgs").data().asNioFloat().get(inputBuffer, img_len , img_len);
        inputMap.get("desire").data().asNioFloat().get(inputBuffer, img_len * 2, desire_len);
        float[] netOutputs = executeModel(inputBuffer);
        System.arraycopy(netOutputs, 0, outputMap.get("outputs"), 0, outputMap.get("outputs").length);
        Log.i("hi","From runn");
    }
}
