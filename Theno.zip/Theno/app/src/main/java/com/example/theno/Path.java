package com.example.theno;

import java.nio.file.Paths;

public class Path {
    @SuppressWarnings("NewApi")
    public static String getFlowPilotRoot() {
        return "/sdcard/hashmebaby/";
    }

    @SuppressWarnings("NewApi")
    public static String internal(String relativePath) {
        return Paths.get(getFlowPilotRoot(), relativePath).toString();
    }

    public static String getModelDir() {
        return internal("models/supercombo");
    }
}