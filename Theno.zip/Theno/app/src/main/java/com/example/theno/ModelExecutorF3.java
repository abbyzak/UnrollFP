package com.example.theno;

import com.example.theno.Definitions;
import com.example.theno.transforms.MsgModelRaw;

import org.capnproto.PrimitiveList;
import org.nd4j.linalg.api.buffer.DataBuffer;
import org.nd4j.linalg.api.buffer.DataType;
import org.nd4j.linalg.api.buffer.util.DataTypeUtil;
import org.nd4j.linalg.api.memory.MemoryWorkspace;
import org.nd4j.linalg.api.memory.conf.WorkspaceConfiguration;
import org.nd4j.linalg.api.memory.enums.AllocationPolicy;
import org.nd4j.linalg.api.memory.enums.LearningPolicy;
import org.nd4j.linalg.api.ndarray.INDArray;
import org.nd4j.linalg.factory.Nd4j;
import org.nd4j.linalg.indexing.INDArrayIndex;
import org.nd4j.linalg.indexing.NDArrayIndex;
import org.nd4j.linalg.inverse.InvertMatrix;

import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import static com.example.theno.MsgFrameBuffer.updateImageBuffer;

public class ModelExecutorF3 {

    public static ModelExecutorF3 instance;
    public boolean stopped = true;
    public boolean initialized = false;
    public long timePerIt = 0;
    public static long AvgIterationTime = 0;
    public long iterationNum = 1;
    public static double numElements(int[] shape){
        double ret = 1;
        for (int i:shape)
            ret *= i;
        return ret;
    }
    public INDArrayIndex[] featureRotateSlice0;
    public INDArrayIndex[] featureRotateSlice1;
    public INDArrayIndex[] desireFeatureSlice0;
    public INDArrayIndex[] desireFeatureSlice1;
    /*From parent class ModelExecutor*/
    public final INDArray rpy_calib = Nd4j.zeros(3);
    public static Definitions.FrameData.Reader frameData;
    public static Definitions.FrameData.Reader frameWideData;
    public static Definitions.FrameBuffer.Reader msgFrameBuffer;
    public static Definitions.FrameBuffer.Reader msgFrameWideBuffer;

    public static int[] imgTensorShape = {1, 12, 128, 256};
    public static int[] featureTensorShape;
    public static int[] desireTensorShape;
    public static final int[] trafficTensorShape = {1, 2};
    public static final int[] outputTensorShape = {1, 6504};
    public static final int[] navFeaturesTensorShape = {1, 64};
    public static final int[] navInstructionsTensorShape = {1, 150};

    public static final Map<String, int[]> inputShapeMap = new HashMap<>();
    public static final Map<String, int[]> outputShapeMap = new HashMap<>();
    public INDArray desireNDArr;
    public INDArray trafficNDArr;
    public INDArray featuresNDArr;
    public INDArray navfeaturesNDArr;
    public INDArray navinstructNDArr;
    public final float[] netOutputs = new float[(int)numElements(outputTensorShape)];
    public final float[]prevDesire = new float[8];
    public final float[]desireIn = new float[8];
    public final Map<String, INDArray> inputMap =  new HashMap<>();
    public final Map<String, float[]> outputMap =  new HashMap<>();

    public static final int[] FULL_FRAME_SIZE = Camera.frameSize;
    public MsgModelRaw msgModelRaw = new MsgModelRaw(6504);
    public Definitions.LiveCalibrationData.Reader liveCalib;

    public long start, end;
    public int lastFrameID = 0;

    int desire;
    public THNEEDModelRunner modelRunner;
    ByteBuffer imgBuffer;
    ByteBuffer wideImgBuffer;
    final WorkspaceConfiguration wsConfig = WorkspaceConfiguration.builder()
            .policyAllocation(AllocationPolicy.STRICT)
            .policyLearning(LearningPolicy.FIRST_LOOP)
            .build();
    public static INDArray eulerAnglesToRotationMatrix(double roll, double pitch, double yaw, boolean isDegrees){
        if (isDegrees){
            yaw = Math.toRadians(yaw);
            pitch = Math.toRadians(pitch);
            roll = Math.toRadians(roll);
        }

        float rot[][] = new float[3][3];

        float cp = (float) Math.cos(pitch);
        float sp = (float) Math.sin(pitch);
        float sr = (float) Math.sin(roll);
        float cr = (float) Math.cos(roll);
        float sy = (float) Math.sin(yaw);
        float cy = (float) Math.cos(yaw);

        rot[0][0] = cp * cy;
        rot[1][0] = (sr * sp * cy) - (cr * sy);
        rot[2][0] = (cr * sp * cy) + (sr * sy);
        rot[0][1] = cp * sy;
        rot[1][1] = (sr * sp * sy) + (cr * cy);
        rot[2][1] = (cr * sp * sy) - (sr * cy);
        rot[0][2] = -sp;
        rot[1][2] = sr * cp;
        rot[2][2] = cr * cp;

        INDArray R = Nd4j.create(rot);
        return R.transpose();
    }
    public ModelExecutorF3(THNEEDModelRunner modelRunner){
        this.modelRunner = modelRunner;
        instance = this;
    }

    public static boolean isIntrinsicsValid(float[] intrinsics){
        return intrinsics[0]!=0 & intrinsics[2]!=0 & intrinsics[4]!=0 & intrinsics[5]!=0 & intrinsics[8]!=0;
    }

    INDArray netInputBuffer, netInputWideBuffer;
    INDArray wrapMatrix;
    INDArray wrapMatrixWide;
    ImagePrepare imageWidePrepare;
    ImagePrepare imagePrepare;

    public static final INDArray sbigmodel_intrinsics = Nd4j.createFromArray(new float[][]{
            {455.0f,  0.0f,  0.5f * 512},
            {0.0f,  455.0f,      0.5f * (256 + 47.6f)},
            {0.0f,  0.0f,  1.0f}
    });
    public static final INDArray medmodel_intrinsics = Nd4j.createFromArray(new float[][]{
            {910.0f,  0.0f,  0.5f * 512},
            {0.0f,  910.0f,      47.6f},
            {0.0f,  0.0f,  1.0f}
    });
    public static INDArray sbigmodel_from_calib = sbigmodel_intrinsics.mmul(Camera.view_from_device);
    public static INDArray medmodel_from_calib = medmodel_intrinsics.mmul(Camera.view_from_device);

    public void ExecuteModel(Definitions.FrameData.Reader wideData, Definitions.FrameBuffer.Reader wideBuf,
                             long processStartTimestamp) {
        frameWideData = frameData = wideData;
        msgFrameWideBuffer = msgFrameBuffer = wideBuf;

        if (stopped || initialized == false) return;

        start = System.currentTimeMillis();
        imgBuffer = updateImageBuffer(msgFrameBuffer, imgBuffer);
        wideImgBuffer = updateImageBuffer(msgFrameWideBuffer, wideImgBuffer);
        /**
         No desirte for nw
         */

        desireNDArr.put(desireFeatureSlice0, desireNDArr.get(desireFeatureSlice1));
        for (int i=1; i<8; i++){
            if (desireIn[i] - prevDesire[i] > 0.99f) {
                    desireNDArr.putScalar(0, 99, i, desireIn[i]);
            } else {
                    desireNDArr.putScalar(0, 99, i,0.0f);
            }
            prevDesire[i] = desireIn[i];
        }

        /*
        No live calibration too
         */

        netInputBuffer = imagePrepare.prepare(imgBuffer, wrapMatrix);
        netInputWideBuffer = imageWidePrepare.prepare(wideImgBuffer, wrapMatrixWide);

        inputMap.put("input_imgs", netInputBuffer);
        inputMap.put("big_input_imgs", netInputWideBuffer);
        modelRunner.run(inputMap, outputMap);
        
        // publish outputs
        end = System.currentTimeMillis();
        msgModelRaw.fill(netOutputs, processStartTimestamp, lastFrameID, 0, 0f, end - start);

        // compute runtime stats every 10 runs
        timePerIt += end - processStartTimestamp;
        iterationNum++;
        if (iterationNum > 10) {
            AvgIterationTime = timePerIt / iterationNum;
            iterationNum = 0;
            timePerIt = 0;
        }

        lastFrameID = frameData.getFrameId();
    }
    public static INDArray getWrapMatrix(INDArray rpy_calib, INDArray road_intrinsics, INDArray wide_intrinsics, boolean wide_cam, boolean big_model) {
        INDArray intrinsics;
        if (wide_cam)
            intrinsics = wide_intrinsics;
        else
            intrinsics = road_intrinsics;

        INDArray calib_from_model;
        if (big_model)
            calib_from_model = InvertMatrix.invert(sbigmodel_from_calib, false);
        else
            calib_from_model = InvertMatrix.invert(medmodel_from_calib, false);

        INDArray device_from_calib = eulerAnglesToRotationMatrix(rpy_calib.getDouble(0), rpy_calib.getDouble(1), rpy_calib.getDouble(2), false);
        INDArray camera_from_calib = intrinsics.mmul(Camera.view_from_device.mmul(device_from_calib));
        INDArray warp_matrix = camera_from_calib.mmul(calib_from_model);
        return warp_matrix;
    }
    public void init(){
        if (initialized) return;

        featureRotateSlice0 = new INDArrayIndex[]{NDArrayIndex.point(0), NDArrayIndex.interval(0, 99-1), NDArrayIndex.all() };
        featureRotateSlice1 = new INDArrayIndex[]{NDArrayIndex.point(0), NDArrayIndex.interval(1, 99), NDArrayIndex.all() };
        desireFeatureSlice0 = new INDArrayIndex[]{NDArrayIndex.point(0), NDArrayIndex.interval(0, 99), NDArrayIndex.all() };
        desireFeatureSlice1 = new INDArrayIndex[]{NDArrayIndex.point(0), NDArrayIndex.interval(1, 99+1), NDArrayIndex.all() };
        featureTensorShape = new int[] {1, 99, 512 };
        desireTensorShape = new int[] {1, 99+1, 8 };

        desireNDArr = Nd4j.zeros(desireTensorShape);
        trafficNDArr = Nd4j.zeros(trafficTensorShape);
        featuresNDArr = Nd4j.zeros(featureTensorShape);
        navfeaturesNDArr = Nd4j.zeros(navFeaturesTensorShape);
        navinstructNDArr = Nd4j.zeros(navInstructionsTensorShape);

        inputShapeMap.put("input_imgs", imgTensorShape);
        inputShapeMap.put("big_input_imgs", imgTensorShape);
        inputShapeMap.put("features_buffer", featureTensorShape);
        inputShapeMap.put("desire", desireTensorShape);
        inputShapeMap.put("traffic_convention", trafficTensorShape);
        inputShapeMap.put("nav_features", navFeaturesTensorShape);
        outputShapeMap.put("outputs", outputTensorShape);

        inputMap.put("nav_features", navfeaturesNDArr);
        inputMap.put("nav_instructions", navinstructNDArr);
        inputMap.put("features_buffer", featuresNDArr);
        inputMap.put("desire", desireNDArr);
        inputMap.put("traffic_convention", trafficNDArr);
        outputMap.put("outputs", netOutputs);

        modelRunner.init(inputShapeMap, outputShapeMap);

        wrapMatrix = getWrapMatrix(rpy_calib, Camera.cam_intrinsics, Camera.cam_intrinsics, true, false);
        wrapMatrixWide = getWrapMatrix(rpy_calib, Camera.cam_intrinsics, Camera.cam_intrinsics, true, true);

        // wait for a frame
        while (msgFrameBuffer == null) {
            try {
                Thread.sleep(10);
            } catch (Exception e) {}
        }

        // TODO:Clean this shit.
        boolean rgb;
            rgb = msgFrameBuffer.getEncoding() == Definitions.FrameBuffer.Encoding.RGB;
            imagePrepare = new ImagePrepare(FULL_FRAME_SIZE[0], FULL_FRAME_SIZE[1], rgb, msgFrameBuffer.getYWidth(), msgFrameBuffer.getYHeight(),
                    msgFrameBuffer.getYPixelStride(), msgFrameBuffer.getUvWidth(), msgFrameBuffer.getUvHeight(), msgFrameBuffer.getUvPixelStride(),
                    msgFrameBuffer.getUOffset(), msgFrameBuffer.getVOffset(), msgFrameBuffer.getStride());
            rgb = msgFrameWideBuffer.getEncoding() == Definitions.FrameBuffer.Encoding.RGB;
            imageWidePrepare = new ImagePrepare(FULL_FRAME_SIZE[0], FULL_FRAME_SIZE[1], rgb, msgFrameWideBuffer.getYWidth(), msgFrameWideBuffer.getYHeight(),
                    msgFrameWideBuffer.getYPixelStride(), msgFrameWideBuffer.getUvWidth(), msgFrameWideBuffer.getUvHeight(), msgFrameWideBuffer.getUvPixelStride(),
                    msgFrameWideBuffer.getUOffset(), msgFrameWideBuffer.getVOffset(), msgFrameWideBuffer.getStride());

        initialized = true;
    }

    public long getIterationRate() {
        return timePerIt/iterationNum;
    }

    public boolean isRunning() {
        return !stopped;
    }

    public boolean isInitialized(){
        return initialized;
    }

    public void dispose(){
        // dispose
        stopped = true;
        wrapMatrix.close();
        wrapMatrixWide.close();

        for (String inputName : inputMap.keySet()) {
            inputMap.get(inputName).close();
        }
        imagePrepare.dispose();
        imageWidePrepare.dispose();
    }

    public void stop() {
        stopped = true;
    }

    public void start(){
        stopped = false;
    }
}
