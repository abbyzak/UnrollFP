package com.example.theno;

import android.Manifest;
import android.content.Context;
import android.os.Bundle;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import java.io.BufferedInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class Model extends Fragment {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;

    private OnModelExecutionListener listener;

    private TextView statusTextView;
    private ProgressBar executionProgressBar;
    private Button startButton;

    public interface OnModelExecutionListener {
        void onModelExecutionUpdate(String status);
        void onModelExecutionComplete(String result);
    }

    public Model() {
        // Required empty public constructor
    }

    public static Model newInstance(String param1, String param2) {
        Model fragment = new Model();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnModelExecutionListener) {
            listener = (OnModelExecutionListener) context;
        } else {
            throw new RuntimeException(context.toString() + " must implement OnModelExecutionListener");
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_model, container, false);

        // Initialize views
        statusTextView = view.findViewById(R.id.statusTextView);
        executionProgressBar = view.findViewById(R.id.executionProgressBar);
        startButton = view.findViewById(R.id.startButton);

        // Set up the start button
        startButton.setOnClickListener(v -> startExecution());

        return view;
    }

    private void startExecution() {
        // Disable the start button and show the progress bar
        startButton.setEnabled(false);
        executionProgressBar.setVisibility(ProgressBar.VISIBLE);
        statusTextView.setText("Downloading model...");

        // Start the download process
        new Thread(() -> {
            downloadModelFile();
            getActivity().runOnUiThread(this::executeModelInBackground);
        }).start();
    }

    private void downloadModelFile() {
        String fileUrl = "https://github.com/phr00t/flowpilot/raw/master/selfdrive/assets/models/f3/supercombo.thneed";
        String fileName = "supercombo.thneed";
        String modelPath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getPath() + "/" + fileName;

        try {
            URL url = new URL(fileUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.connect();

            int fileLength = connection.getContentLength();

            InputStream input = new BufferedInputStream(connection.getInputStream());
            FileOutputStream output = new FileOutputStream(modelPath);

            byte[] data = new byte[4096];
            long total = 0;
            int count;
            while ((count = input.read(data)) != -1) {
                total += count;
                output.write(data, 0, count);

                // Update progress
                final int progress = (int) (total * 100 / fileLength);
                getActivity().runOnUiThread(() -> statusTextView.setText("Download progress: " + progress + "%"));
            }

            output.flush();
            output.close();
            input.close();
        } catch (Exception e) {
            e.printStackTrace();
            getActivity().runOnUiThread(() -> statusTextView.setText("Download failed"));
        }

        getActivity().runOnUiThread(() -> statusTextView.setText("Download complete"));
    }

    private void executeModelInBackground() {
        statusTextView.setText("Execution started...");

        new Thread(() -> {
            if (listener != null) {
                listener.onModelExecutionUpdate("Waiting...");
            }

            String modelPath = Path.getModelDir();
            THNEEDModelRunner model = new THNEEDModelRunner(modelPath, getActivity().getApplication());
            ModelExecutorF3 exec = new ModelExecutorF3(model);
            exec.init();

            long startTime = System.currentTimeMillis(); // Start time
            for (int i = 0; i < 100; i++) {
                exec.ExecuteModel();
                final int progress = i + 1;
                getActivity().runOnUiThread(() -> executionProgressBar.setProgress(progress));
            }
            long endTime = System.currentTimeMillis(); // End time
            long duration = endTime - startTime; // Calculate time taken

            String resultMessage = "Executed successfully in " + duration / 100 + " ms and " + (100000 / duration) + " FPS";

            if (listener != null) {
                listener.onModelExecutionComplete(resultMessage);
            }

            getActivity().runOnUiThread(() -> {
                statusTextView.setText("Execution complete");
                executionProgressBar.setVisibility(ProgressBar.INVISIBLE);
            });

        }).start();
    }

    @Override
    public void onDetach() {
        super.onDetach();
        listener = null;
    }
}
